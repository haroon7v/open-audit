# frozen_string_literal: true

require 'require_all'
require 'logger'
# require 'pry'
require 'optparse'
require 'ostruct'
require 'assetsonar_syncer/constants'
require 'assetsonar_syncer/config'
require 'assetsonar_syncer/version'
require 'assetsonar_syncer/exceptions'
require 'assetsonar_syncer/syncers/syncer'
require_all File.expand_path('assetsonar_syncer/syncers', __dir__)

module AssetsonarSyncer
  class << self
    attr_writer :loggers

    def logger(name = 'main')
      @loggers ||= {}
      @loggers[name] ||= Logger.new("#{LOG_PATH}/#{name}.log", 'monthly', level: @logger_level)
    end

    def logger_level=(level)
      @logger_level_int = level
      @logger_level = LOG_LEVEL[level]
    end

    def log_messages(*messages, log_class: 'main', level: 1, print_msg: true)
      log_level = Logger.const_get(LOG_LEVEL[level])

      messages.each do |message|
        puts(message) if print_msg && level >= @logger_level_int
        @loggers[log_class].add(log_level, message)
      end
    end

    def log_debug(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 0, print_msg: print_msg)
    end

    def log_info(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 1, print_msg: print_msg)
    end

    def log_warn(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 2, print_msg: print_msg)
    end

    def log_error(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 3, print_msg: print_msg)
    end

    def log_fatal(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 4, print_msg: print_msg)
    end

    def log_unknown(*messages, log_class: 'main', print_msg: true)
      log_messages(messages, log_class: log_class, level: 5, print_msg: print_msg)
    end
  end

  class Main
    def load_assetsonar_syncer(config_info)
      @assetsonar_syncer = initialize_syncer(SYNCERS[:assetsonar], config_info[SYNCERS[:assetsonar]])
    rescue SyncerVerificationError => e
      AssetsonarSyncer.log_error('Unable to verify connection to AssetSonar', e)
      raise AssetsonarSyncerError
    rescue StandardError => e
      AssetsonarSyncer.log_error(e, e.backtrace.join("\n"))
      raise AssetsonarSyncerError
    end

    def load_non_assetsonar_syncers(config_info)
      SYNCERS.reject { |key, _val| key == :assetsonar }.each_value do |syncer|
        error = nil
        AssetsonarSyncer.log_error("Loading Syncers: #{syncer}: #{config_info[syncer]} \n")
        next if config_info[syncer].nil? || !config_info[syncer]['sync_enabled']

        begin
          @non_assetsonar_syncers[syncer] = initialize_syncer(syncer, config_info[syncer])
        rescue SyncerVerificationError => e
          AssetsonarSyncer.log_error("Unable to verify connection to #{syncer} #{e} ")
          error = e
        rescue StandardError => e
          error = e
          AssetsonarSyncer.log_error("Unable to load syncer for #{syncer}", e, e.backtrace.join("\n"))
        ensure
          unless error.nil?
            @assetsonar_syncer.post_health_check(error_type: e.class.name,
                                                 error_message: e.message,
                                                 backtrace: e.backtrace,
                                                 source: 'load_syncer')
          end
        end
      end
    end

    def initialize_syncer(syncer_name, settings)
      AssetsonarSyncer.const_get(syncer_name).new(settings).tap do |s|
        s.initialize_logger
        raise SyncerVerificationError if s.verify_connection == false
      end
    end

    def sync(ini_file, force)
      begin
        AssetsonarSyncer.log_error("Initiating Sync")
        config_info = Config.read_config(ini_file)
        load_assetsonar_syncer(config_info)
        AssetsonarSyncer.log_error("Assetsonar Syncer Loaded")
      rescue ConfigError
        AssetsonarSyncer.log_fatal('Unable to read the configuration file. Terminating the program...')
        exit(1)
      rescue AssetsonarSyncerError
        AssetsonarSyncer.log_fatal('Unable to load Assetsonar Syncer. Terminating the program...')
        exit(1)
      end

      AssetsonarSyncer.log_error("Loading OpenAudit Syncer")
      load_non_assetsonar_syncers(config_info)
      AssetsonarSyncer.log_error("OpenAudit Syncer Loaded")

      @non_assetsonar_syncers.values.each do |syncer|
        begin
          AssetsonarSyncer.log_info("Starting #{syncer.class::NAME} sync")
          syncer.sync(@assetsonar_syncer, force: force)
          AssetsonarSyncer.log_info("#{syncer.class::NAME} sync complete. Refer to #{syncer.class::NAME}.log for errors.")
        rescue FunctionNotImplementedError
          AssetsonarSyncer.log_error("A function has not been implemented for #{syncer.class::NAME}. Refer to #{syncer.class::NAME}.log for details.")
        end
      end
    end

    def execute(ini_file)
      begin
        config_info = Config.read_config(ini_file)
        load_assetsonar_syncer(config_info)
      rescue ConfigError
        AssetsonarSyncer.log_fatal('Unable to read the configuration file. Terminating the program...')
        exit(1)
      rescue AssetsonarSyncerError
        AssetsonarSyncer.log_fatal('Unable to load Assetsonar Syncer. Terminating the program...')
        exit(1)
      end

      load_non_assetsonar_syncers(config_info)

      @non_assetsonar_syncers.values.each do |syncer|
        begin
          if syncer.respond_to?(:execute)
            AssetsonarSyncer.log_info("Starting execution for #{syncer.class::NAME}")
            syncer.execute(@assetsonar_syncer)
            AssetsonarSyncer.log_info("#{syncer.class::NAME} execution complete. Refer to #{syncer.class::NAME}.log for errors.")
          end
        rescue FunctionNotImplementedError
          AssetsonarSyncer.log_error("A function has not been implemented for #{syncer.class::NAME}. Refer to #{syncer.class::NAME}.log for details.")
        end
      end
    end

    def run
      options = parse_arguments

      AssetsonarSyncer.logger_level = options.log_level
      AssetsonarSyncer.logger() # Initialize logger
      AssetsonarSyncer.log_info("Syncer version #{AssetsonarSyncer::VERSION} started.")

      if options.sync
        sync(options.ini, options.force)
      elsif options.execute
        execute(options.ini)
      elsif options.gen_config
        Config.write_config(options.ini, SYNCERS.values)
      elsif options.version
        puts(AssetsonarSyncer::VERSION)
      else
        AssetsonarSyncer.log_fatal('Invalid flags provided, exiting...')
      end

      exit(0)
    rescue StandardError => e
      AssetsonarSyncer.log_error("Error Occured: #{e}, #{e.backtrace.join("\n")}")
      exit(1)
    end

    def initialize
      @non_assetsonar_syncers = {}
    end

    def parse_arguments
      options = OpenStruct.new

      OptionParser.new do |opt|
        opt.on('-s', '--sync', 'Perform sync and send data to AssetSonar.') { |o| options.sync = o }
        opt.on('-f', '--force', 'Use with the sync command to force sync all data.') { |o| options.force = o }
        opt.on('-e', '--execute', 'Execute discoveries.') { |o| options.execute = o }
        opt.on('--generate-config', 'Generate configuration file.') { |o| options.gen_config = o }
        opt.on('--ini INI', 'Path of the configuration file to be used/generated.') { |o| options.ini = File.expand_path(o) }
        opt.on('-v', '--version', 'Show the version of AssetsonarSyncer being used.') { |o| options.version = o }
        opt.on('--log-level LOG_LEVEL', 'Set severity of information to be logged (0-5).') { |o| options.log_level = o.to_i }
      end.parse!

      options.ini ||= CONFIG_PATH
      options.log_level ||= 1

      options
    end
  end
end
