# frozen_string_literal: true

require 'inifile'

module AssetsonarSyncer
  # Manages the .ini configuration files
  module Config
    def self.read_config(file_path)
      AssetsonarSyncer.log_info("Reading config_file #{file_path}")
      config_info = {}

      begin
        config_file = IniFile.load(file_path)
      rescue StandardError => e
        AssetsonarSyncer.log_error(e, e.backtrace.join("\n"))
        raise AssetsonarSyncer::ConfigError
      end

      raise AssetsonarSyncer::ConfigError if config_file.nil?

      config_file.each_section do |section|
        config_info[section] = config_file[section]
      end

      AssetsonarSyncer.log_info('Config file read successfully.')
      config_info
    end

    def self.write_config(file_path, syncers_list)
      AssetsonarSyncer.log_info("Generating file #{file_path} ...")

      if File.file?(file_path)
        AssetsonarSyncer.log_info('Configuration file already exists')
        return
      end

      File.open(file_path, 'w') do |f|
        syncers_list.each_with_index do |syncer, index|
          f.write "[#{syncer}]\n"

          attributes = Syncer::CONFIG_SETTINGS.merge(AssetsonarSyncer.const_get(syncer)::CONFIG_SETTINGS)
          attributes.reject! { |key, val| key == :sync_enabled } if syncer == AssetsonarSyncer::SYNCERS[:assetsonar]
          write_attributes(attributes, f)

          f.write "\n" unless index == syncers_list.size - 1
        end
      end

      AssetsonarSyncer.log_info('Configuration file successfully generated!')
    rescue StandardError => e
      AssetsonarSyncer.log_error(e, e.backtrace.join("\n"))
      raise AssetsonarSyncer::ConfigError
    end

    def self.write_attributes(attributes_hash, file)
      attributes_hash.each do |setting, value|
        file.write "#{setting} = #{value}\n"
      end
    end
  end
end
