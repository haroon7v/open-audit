# frozen_string_literal: true

module AssetsonarSyncer
  SYNCERS = { assetsonar: 'Assetsonar', open_audit: 'OpenAudit' }.freeze
  LOG_LEVEL = { 0 => 'DEBUG', 1 => 'INFO', 2 => 'WARN', 3 => 'ERROR', 4 => 'FATAL', 5 => 'UNKNOWN' }.freeze
  LOG_PATH = '/var/log/assetsonar-connector'
  DATA_PATH = '/var/lib/assetsonar-connector'
  CONFIG_PATH = File.expand_path('config.ini', DATA_PATH)
end
