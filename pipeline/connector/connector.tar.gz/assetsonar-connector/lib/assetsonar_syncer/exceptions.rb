# frozen_string_literal: true

module AssetsonarSyncer
  class ConfigError < StandardError; end
  class SyncerVerificationError < StandardError; end
  class AssetsonarSyncerError < StandardError; end
  class FunctionNotImplementedError < StandardError; end
end
