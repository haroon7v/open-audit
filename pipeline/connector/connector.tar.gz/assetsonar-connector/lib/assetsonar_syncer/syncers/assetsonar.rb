# frozen_string_literal: true

require 'json'

module AssetsonarSyncer
  # Manages communication with AssetSonar
  class Assetsonar < Syncer
    NAME = SYNCERS[:assetsonar]

    CONFIG_SETTINGS = {
      'url': 'https://<company_name>.assetsonar.com',
      'tag': 'your assetsonar Agent Tag'
    }.freeze

    def initialize(settings)
      super
      @settings['url'] = @settings['url'].strip.chomp('/')
    end

    def post_assets_path
      "#{@settings['url']}/api/api_integration/sync_it_assets.api"
    end

    def post_health_check_path
      "#{@settings['url']}/api/api_integration/health_check.api"
    end

    def get_schedule_path(api_type, options = {})
      path = "#{@settings['url']}/api/api_integration/get_scan_schedule.api?api_type=#{api_type}"
      path += "&system_id=#{options[:system_id]}" unless options[:system_id].nil?
      path
    end

    def post_discoveries_path
      "#{@settings['url']}/api/api_integration/sync_network_scans.api"
    end

    def subdomain_path
      "#{@settings['url']}/api/api_integration/company_subdomain_via_agent_tag.api"
    end

    def post_assets_headers
      headers(tag: true, json_content: true)
    end

    def post_health_check(**args)
      payload = {
        api_type: 'open_audit',
        itam_access_token: @settings['tag'],
        apache_status: `systemctl is-active apache2`.strip,
        open_audit_installed: Dir.exist?('/var/www/html/open-audit'),
        **args
      }

      post(post_health_check_path, payload.to_json, post_assets_headers)
    rescue StandardError => e
      AssetsonarSyncer.log_error(e, e.backtrace.join("\n"), log_class: NAME)
    end

    def post_assets(assets, assets_count, api_type, post_options = {})
      AssetsonarSyncer.log_info("Posting #{assets_count} assets from #{api_type} to Assetsonar...", log_class: NAME)
      begin
        post_data = { assets: assets, api_type: api_type }
        post_data.merge!(post_options)

        post(post_assets_path, post_data.to_json, post_assets_headers)
      rescue StandardError => e
        AssetsonarSyncer.log_error(e, e.backtrace.join("\n"), log_class: NAME)
      end
    end

    def post_discoveries?(discoveries, api_type, post_options = {})
      AssetsonarSyncer.log_info("Posting #{discoveries.size} discoveries from #{api_type} to Assetsonar...", log_class: NAME)
      begin
        post_data = { discovery_data: discoveries, api_type: api_type }
        post_data.merge!(post_options)

        post(post_discoveries_path, post_data.to_json, post_assets_headers)
        true
      rescue StandardError => e
        AssetsonarSyncer.log_error(e, e.backtrace.join("\n"), log_class: NAME)
        false
      end
    end

    def get_scheduling_data(api_type, options = {})
      AssetsonarSyncer.log_info("Attempting to get scheduling data for #{api_type} from Assetsonar...", log_class: NAME)
      begin
        response = get(get_schedule_path(api_type, options), headers(tag: true))
        JSON.parse(response)
      rescue StandardError => e
        AssetsonarSyncer.log_error(e, e.backtrace.join("\n"), log_class: NAME)
        nil
      end
    end

    def headers(options = {})
      headers = {}
      headers[:itam_access_token] = @settings['tag'] if options[:tag]
      headers['Content-Type'] = 'application/json' if options[:json_content]
      headers
    end

    def initialize_logger
      AssetsonarSyncer.logger(NAME)
    end

    def verify_connection
      response = JSON.parse(get(subdomain_path, headers(tag: true)))
      response['error'].nil?
    rescue StandardError => e
      AssetsonarSyncer.log_error(e, e.backtrace.join("\n"), log_class: NAME)
      false
    end
  end
end
