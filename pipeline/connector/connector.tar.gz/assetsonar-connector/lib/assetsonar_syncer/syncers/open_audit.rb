# frozen_string_literal: true

module AssetsonarSyncer
  # Handles communication and syncing with OpenAudit
  class OpenAudit < Syncer
    NAME = SYNCERS[:open_audit]
    API_TYPE = 'open_audit'

    CONFIG_SETTINGS = {
      'url': 'http://localhost/open-audit/index.php',
      'username': 'admin',
      'password': 'password',
      'system_id': 'System1 # If you plan to install multiple instances of Open Audit, make sure this value is unique for each respective installation of the connector application. Do not leave this empty.'
    }.freeze

    class Discovery
      attr_accessor :last_sent, :id, :repeat_every_duration, :repeat_every_count, :starting_from, :ending_on, :schedule_updated_on, :last_auto_executed

      COMPLETE = 'complete'
      DURATIONS = { days: 'Days', weeks: 'Weeks', months: 'Months', years: 'years' }.freeze

      def initialize(id, repeat_every_count, repeat_every_duration, starting_from, ending_on, last_sent, last_auto_executed, schedule_updated_on)
        @id = id
        @repeat_every_count = repeat_every_count
        @repeat_every_duration = repeat_every_duration
        @starting_from = starting_from
        @ending_on = ending_on
        @last_sent = last_sent
        @last_auto_executed = last_auto_executed
        @schedule_updated_on = schedule_updated_on
      end

      def to_json
        {
          id: @id,
          repeat_every_count: @repeat_every_count,
          repeat_every_duration: @repeat_every_duration,
          starting_from: @starting_from,
          ending_on: @ending_on,
          last_sent: @last_sent,
          last_auto_executed: @last_auto_executed,
          schedule_updated_on: @schedule_updated_on
        }.to_json
      end

      def self.discovery_path(id)
        File.expand_path("discovery_#{id}", DATA_PATH)
      end

      def save
        File.open(Discovery.discovery_path(@id), 'w') do |f|
          f.write self.to_json
        end
      end

      def schedule_set?
        !@repeat_every_duration.nil?
      end

      def next_execution_time
        return @starting_from if @last_auto_executed.nil?

        if @repeat_every_duration == DURATIONS[:days]
          @last_auto_executed + repeat_every_count
        elsif @repeat_every_duration == DURATIONS[:weeks]
          @last_auto_executed + (7 * repeat_every_count)
        elsif @repeat_every_duration == DURATIONS[:months]
          @last_auto_executed >> repeat_every_count
        elsif @repeat_every_duration == DURATIONS[:years]
          @last_auto_executed >> (12 * repeat_every_count)
        end
      end

      def update_last_auto_executed
        @last_auto_executed = @starting_from if @last_auto_executed.nil?

        temp_next_execution_time = next_execution_time
        current_time = DateTime.now

        while (temp_next_execution_time < current_time)
          @last_auto_executed = temp_next_execution_time
          temp_next_execution_time = next_execution_time
        end

        save
      end

      def self.load_discovery(id)
        discovery_data = JSON.parse(File.read(Discovery.discovery_path(id)))

        Discovery.new(
          discovery_data['id'],
          discovery_data['repeat_every_count'],
          discovery_data['repeat_every_duration'],
          discovery_data['starting_from'].nil? ? nil : DateTime.parse(discovery_data['starting_from']),
          discovery_data['ending_on'].nil? ? nil : DateTime.parse(discovery_data['ending_on']),
          discovery_data['last_sent'].nil? ? nil : DateTime.parse(discovery_data['last_sent']),
          discovery_data['last_auto_executed'].nil? ? nil : DateTime.parse(discovery_data['last_auto_executed']),
          discovery_data['schedule_updated_on'].nil? ? nil : DateTime.parse(discovery_data['schedule_updated_on'])
        )
      rescue Errno::ENOENT => e # File not found
        AssetsonarSyncer.log_error("File not found for discovery #{id}", e, log_class: NAME)
        nil
      end

      def clear_schedule
        @repeat_every_count = nil
        @repeat_every_duration = nil
        @starting_from = nil
        @ending_on = nil
        @last_auto_executed = nil
        @schedule_updated_on = nil

        save
      end

      def self.update_schedules(scheduling_data)
        update_start_time = DateTime.now - Rational(10, 86400) # subtracting 10 seconds to avoid comparison issues 

        scheduling_data.each do |schedule_info|
          discovery = Discovery.load_discovery(schedule_info['network_scan']['open_audit_id'])
          next if discovery.nil?

          discovery.last_auto_executed = nil if discovery.starting_from != DateTime.parse(schedule_info['time_in_utc'])
          discovery.repeat_every_duration = schedule_info['repeat_every_duration']
          discovery.repeat_every_count = schedule_info['repeat_every_count']
          discovery.starting_from = DateTime.parse(schedule_info['time_in_utc'])
          discovery.ending_on = DateTime.parse(schedule_info['ending_on'])
          discovery.schedule_updated_on = DateTime.now

          discovery.save
        end

        # clearing schedules for all discoveries not updated
        Dir["#{DATA_PATH}/discovery_*"].each do |file_name|
          discovery = Discovery.load_discovery(file_name.split('/').last.split('_')[1])
          discovery.clear_schedule if discovery.schedule_set? && discovery.schedule_updated_on < update_start_time
        end
      end
    end

    def initialize(settings)
      super
      @settings['url'] = @settings['url'].strip.chomp('/')
    end

    def connect
      response = post(login_path, credentials)
      @session_id = response.cookies.fetch('ci_session')
    end

    def headers(options = {})
      { 
        'Accept' => 'application/json',
        'Cookie' => "ci_session=#{@session_id}"
      }
    end

    def credentials
      {
        username: @settings['username'],
        password: @settings['password']
      }
    end

    def verify_connection
      if @settings['system_id'].nil? || @settings['system_id'].empty?
        AssetsonarSyncer.log_error('System ID cannot be empty.', log_class: NAME)
        return false
      end

      connect
      !@session_id.nil?
    end

    def sync(assetsonar_syncer, force: false)
      AssetsonarSyncer.log_info('Beginning sync...', log_class: NAME)

      connect
      sync_time = DateTime.now
      discovery_list, time_zone = sync_discoveries(assetsonar_syncer)
      sync_devices(discovery_list, assetsonar_syncer, force, time_zone, sync_time) if discovery_list.size > 0
    end

    # Metadata for all discoveries will be sent, regardless of last sync date since this data is lightweight
    # Device data for discoveries will be sent based on last sync date
    def sync_discoveries(assetsonar_syncer)
      discovery_list = get_discovery_list(assetsonar_syncer)

      if discovery_list.nil?
        AssetsonarSyncer.log_error("Aborting sync!", log_class: NAME)
        return [[], nil]
      end

      if discovery_list['meta']['total'] == 0
        AssetsonarSyncer.log_info("No discoveries found!", log_class: NAME)
        return [[], nil]
      end

      discovery_list['data'].each do |discovery_info|

        discovery = Discovery.load_discovery(discovery_info['id'])

        if discovery.nil?
          discovery = Discovery.new(discovery_info['id'], nil, nil, nil, nil, nil, nil, nil)
          discovery.save
        end
      end

      time_zone = discovery_list['meta']['timezone']

      if assetsonar_syncer.post_discoveries?(discovery_list['data'], API_TYPE, time_zone: time_zone, system_id: @settings['system_id'])
        [discovery_list['data'], time_zone]
      else
        [[], nil]
      end
    end

    def sync_devices(discovery_list, assetsonar_syncer, force, time_zone, sync_time)
      discovery_list.each do |discovery_info|
        discovery = Discovery.load_discovery(discovery_info['id'])

        if !force
          if discovery_info['attributes']['status'] != Discovery::COMPLETE
            AssetsonarSyncer.log_info("Discovery #{discovery_info['id']} is still running. Not sending device data to AS.", log_class: NAME)
            next
          end

          if !discovery.last_sent.nil?
            last_finished = DateTime.parse("#{discovery_info['attributes']['last_finished']} #{time_zone.split(' ')[1]}")
            if discovery.last_sent > last_finished
              AssetsonarSyncer.log_info("Not sending device data to AS for discovery #{discovery_info['id']} since it has not run again since its data was last sent to assetsonar.", log_class: NAME)
              next
            end
          end
        end

        offset    = 0
        success   = true
        last_sent = discovery.last_sent if !force && !discovery.last_sent.nil?

        device_list = get_device_list(assetsonar_syncer, discovery_info['id'], BATCH_SIZE, offset, last_sent)

        while true
          next_device_list = get_device_list(assetsonar_syncer, discovery_info['id'], BATCH_SIZE, offset + BATCH_SIZE, last_sent)
          is_final_batch   = next_device_list['meta']['filtered'] == 0 # current batch is final if the next batch contains no devices

          device_data = []

          # if no devices in current batch (this will only happen if there are no devices for this scan, but we still need to ping assetsonar)
          unless device_list['meta']['filtered'] == 0
            device_list['data'].each do |device_info|
              device_data << get_device_info(device_info['id'])
            end
          end

          AssetsonarSyncer.log_info("Sending batch #{offset / BATCH_SIZE} for discovery #{discovery_info['id']}.", log_class: NAME)

          assetsonar_syncer.post_assets(
            device_data,
            device_data.size,
            API_TYPE,
            time_zone: time_zone,
            system_id: @settings['system_id'],
            final_batch_for_current_scan: is_final_batch,
            sync_time: sync_time.strftime("%Y-%m-%d %H:%M:%S"),
            discovery_id: discovery.id
          )

          offset += BATCH_SIZE
          device_list = next_device_list

          break if is_final_batch
        end

        discovery.last_sent = DateTime.now
        discovery.save
      end
    end

    def execute(assetsonar_syncer)
      scheduling_data = assetsonar_syncer.get_scheduling_data(API_TYPE, system_id: @settings['system_id'])

      if scheduling_data.nil?
        AssetsonarSyncer.log_error("Error fetching scheduling data from AS, using existing schedule to initiate discoveries...", log_class: NAME)
      else
        Discovery.update_schedules(scheduling_data)
      end

      current_time   = DateTime.now.new_offset(0) # offset 0 (UTC) required for comparison
      discovery_list = get_discovery_list(assetsonar_syncer)

      if discovery_list.nil?
        AssetsonarSyncer.log_error("Aborting execution!", log_class: NAME)
        return
      end

      if discovery_list['meta']['total'] == 0
        AssetsonarSyncer.log_info("No discoveries found!", log_class: NAME)
        return
      end

      discovery_list['data'].each do |discovery_info|
        discovery = Discovery.load_discovery(discovery_info['id'])

        if (discovery.nil?)
          AssetsonarSyncer.log_info("File not yet created for discovery #{discovery_info['id']}!", log_class: NAME)
        elsif !discovery.schedule_set?
          AssetsonarSyncer.log_info("Schedule not set for discovery #{discovery_info['id']}", log_class: NAME)
        elsif discovery.ending_on.to_date >= current_time.to_date && discovery.next_execution_time <= current_time
          discovery.update_last_auto_executed if execute_discovery(discovery_info['id'])
        end
      end
    end

    def get_discovery_list(assetsonar_syncer)
      response = get(discoveries_path, headers)
      JSON.parse(response)
    rescue StandardError => e
      AssetsonarSyncer.log_error("Error fetching discovery list", e, e.backtrace.join("\n"), log_class: NAME)
      assetsonar_syncer.post_health_check(error_type: e.class.name,
                                          error_message: e.message,
                                          backtrace: e.backtrace,
                                          source: 'get_discovery_list')
      nil
    end

    def get_device_list(assetsonar_syncer, discovery_id, limit, offset, last_sent)
      response = get(device_list_path(discovery_id, limit, offset, last_sent), headers)
      JSON.parse(response)
    rescue StandardError => e
      assetsonar_syncer.post_health_check(error_type: e.class.name,
                                          error_message: e.message,
                                          backtrace: e.backtrace,
                                          source: 'get_device_list')
      { 'meta' => { 'filtered' => 0 } }
    end

    def get_device_info(device_id)
      response = get(device_info_path(device_id), headers)
      JSON.parse(response)
    end

    def initialize_logger
      AssetsonarSyncer.logger(NAME)
    end

    def login_path
      "#{@settings['url']}/logon"
    end

    def discoveries_path
      "#{@settings['url']}/discoveries"
    end

    def execute_discovery(id)
      begin
        get(execute_discovery_path(id), headers)
        AssetsonarSyncer.log_info("Started execution for discovery #{id}", log_class: NAME)
        true
      rescue StandardError => e
        AssetsonarSyncer.log_error("Failed to execute discovery #{id}", e, e.backtrace.join("\n"), log_class: NAME)
        false
      end
    end

    def execute_discovery_path(id)
      "#{@settings['url']}/discoveries/#{id}/execute"
    end

    def device_list_path(discovery_id, limit, offset, last_sent)
      path = "#{@settings['url']}/devices?properties=devices.id,devices.ip,devices.hostname,devices.domain,devices.type,devices.discovery_id&devices.discovery_id=#{discovery_id}"
      if last_sent.nil?
        path += "&limit=#{limit}&offset=#{offset}"
      else
        last_sent_encoded = URI.encode_www_form_component(last_sent.strftime("%Y-%m-%d %H:%M:%S"))
        path += "&devices.last_seen=>#{last_sent_encoded}&limit=#{limit}&offset=#{offset}"
      end
    end

    def device_info_path(device_id)
      "#{@settings['url']}/devices/#{device_id}?include=bios,memory,monitor,video,partition,disk,processor,network,software"
    end
  end
end
