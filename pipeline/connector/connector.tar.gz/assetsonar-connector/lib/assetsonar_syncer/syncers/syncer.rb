# frozen_string_literal: true

require 'rest-client'

module AssetsonarSyncer
  # Base class for all syncers
  class Syncer
    BATCH_SIZE = 50

    CONFIG_SETTINGS = {
      'sync_enabled': 'false'
    }.freeze

    def initialize(settings)
      @settings = settings
      @connection_verified = false
      @records_sent = 0
      @records_failed = 0
    end

    def sync(_assetsonar_syncer, force: false)
      AssetsonarSyncer.log_error("Sync not implemented for #{self.class::NAME}", log_class: self.class::NAME)
      raise FunctionNotImplementedError
    end

    def get(url, headers = {})
      AssetsonarSyncer.log_info("Initiating get request #{url}", log_class: self.class::NAME)

      response = RestClient.get(url, headers)

      AssetsonarSyncer.log_info("Get Response: #{response}")
      response
    end

    def post(url, payload, headers = {})
      AssetsonarSyncer.log_info("Initiating post request #{url}", log_class: self.class::NAME)

      response = RestClient.post(url, payload, headers)
      AssetsonarSyncer.log_info("Post Response: #{response}", log_class: self.class::NAME)
      response
    end

    def verify_connection
      AssetsonarSyncer.log_error("verify_connection not implemented for #{self.class::NAME}", log_class: self.class::NAME)
      raise FunctionNotImplementedError
    end

    def initialize_logger
      AssetsonarSyncer.log_error("initialize_logger not implemented for #{self.class::NAME}")
      raise FunctionNotImplementedError
    end
  end
end
